import React from "react";
import { motion } from "motion/react";
import { ArrowRight, ChevronDown } from "lucide-react";

export function Hero({ onExplore }: { onExplore: () => void }) {
  return (
    <section className="relative h-screen w-full flex items-center justify-center overflow-hidden bg-black-pure">
      {/* Background Decor */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://images.unsplash.com/photo-1574950578143-858c6fc58922?auto=format&fit=crop&q=80')] bg-cover bg-center grayscale opacity-40 contrast-125" />
        <div className="absolute inset-0 bg-gradient-to-b from-black-pure/60 via-transparent to-black-pure" />
      </div>

      <div className="relative z-10 text-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
          className="flex flex-col items-center"
        >
          <div className="flex items-center gap-4 mb-4 opacity-50">
            <div className="h-[1px] w-8 bg-gold-accent" />
            <span className="text-[10px] uppercase tracking-[0.6em] text-gold-accent font-sans font-bold">Modern French</span>
            <div className="h-[1px] w-8 bg-gold-accent" />
          </div>
          
          <h1 className="font-serif text-[12vw] md:text-[10vw] mb-4 tracking-[-0.05em] leading-none uppercase italic">
            <span className="block text-white-pure">ÉCLIPSE</span>
          </h1>

          <div className="flex flex-col md:flex-row gap-12 items-center mb-16">
            <div className="text-right hidden md:block">
              <span className="text-[9px] tracking-[0.4em] uppercase opacity-40 font-sans block mb-1">Kitchen</span>
              <span className="text-[14px] tracking-[0.2em] font-serif uppercase">그림자 (The Shadow)</span>
            </div>
            
            <div className="h-[1px] w-12 bg-gold-accent opacity-30 rotate-90 hidden md:block" />

            <div className="text-left hidden md:block">
              <span className="text-[9px] tracking-[0.4em] uppercase opacity-40 font-sans block mb-1">Dining</span>
              <span className="text-[14px] tracking-[0.2em] font-serif uppercase">빛 (The Light)</span>
            </div>
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onExplore}
            className="group relative flex items-center gap-6 px-12 py-5 bg-gold-accent text-black-pure transition-all duration-500 overflow-hidden"
          >
            <div className="absolute inset-0 bg-white-pure translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
            <span className="relative z-10 text-[10px] tracking-[0.4em] uppercase font-sans font-bold">에클립스 마주하기</span>
            <ArrowRight size={14} className="relative z-10 transition-transform group-hover:translate-x-2" />
          </motion.button>
        </motion.div>
      </div>

      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 text-white-pure/10"
      >
        <ChevronDown size={24} />
      </motion.div>

      {/* Frame rails */}
      <div className="absolute left-10 top-0 h-full w-[1px] bg-white-pure/5" />
      <div className="absolute right-10 top-0 h-full w-[1px] bg-white-pure/5" />
      <div className="absolute left-0 top-10 w-full h-[1px] bg-white-pure/5" />
      <div className="absolute left-0 bottom-10 w-full h-[1px] bg-white-pure/5" />
    </section>
  );
}
