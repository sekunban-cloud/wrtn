import React from "react";
import { motion } from "motion/react";
import { Flame, ShieldAlert, Timer, Users } from "lucide-react";

export function KitchenSection() {
  const staff = [
    { role: "Head Chef", name: "류진 (Jin Ryu)", style: "text-gold-accent font-bold" },
    { role: "Sous Chef", name: "정지호 (Ji-ho Jeong)", style: "text-white-pure" },
    { role: "CDP — Pâtissier", name: "백태웅 (Tae-woong Baek)", style: "text-white-pure/80" },
    { role: "CDP — Poissonier", name: "황대근 (Dae-geun Hwang)", style: "text-white-pure/80" },
    { role: "CDP — Garde Manger", name: "한성호 (Sung-ho Han)", style: "text-white-pure/80" },
    { role: "CDP — Saucier", name: "강민우 (Min-woo Kang)", style: "text-white-pure/80" },
    { role: "Commis Chef", name: "권시우 (Si-woo Kwon)", style: "text-gold-accent/60" },
    { role: "Commis Chef", name: "Ⓤ (The Rising Talent)", style: "text-gold-accent/60" }
  ];

  return (
    <section className="min-h-screen py-32 px-6 bg-white-pure text-black-pure relative overflow-hidden flex items-center">
      <div className="absolute inset-0 geometric-pattern opacity-40 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="relative"
        >
          <div className="absolute -left-12 top-0 text-[10px] tracking-widest uppercase writing-vertical font-sans opacity-30">
            01 — THE FORGE
          </div>
          
          <div className="mb-12">
            <span className="text-[10px] tracking-[0.4em] uppercase font-sans font-bold text-gold-accent mb-4 block underline decoration-gold-accent/30 underline-offset-8">THE BRIGADE DE CUISINE</span>
            <h2 className="text-5xl md:text-7xl font-serif mb-8 tracking-tight italic">주방 (The Kitchen)</h2>
            <div className="h-[1px] w-24 bg-black-pure/20 mb-10" />
            <p className="text-black-pure/70 leading-relaxed tracking-widest text-sm md:text-base max-w-sm font-sans">
              헤드 셰프 류진의 지휘 아래, 에클립스의 주방은 수술실과 같은 정교함으로 움직입니다. 
              사적인 대화는 금지되며, 오직 불과 강철의 언어만이 허용되는 치열한 전쟁터입니다. 
            </p>
          </div>

          <div className="space-y-10">
            <div className="flex gap-6 items-start group">
              <div className="p-3 border border-black-pure/10 bg-black-pure/5 text-gold-accent group-hover:bg-gold-accent group-hover:text-white transition-all">
                <Flame size={22} />
              </div>
              <div>
                <h4 className="text-[11px] font-sans tracking-[0.2em] text-black-pure uppercase font-bold mb-1">절대적인 온도 통제</h4>
                <p className="text-[10px] text-black-pure/50 leading-relaxed font-sans uppercase tracking-widest">
                  한우 안심은 단면이 루비처럼 붉고 일정해야만 홀로 나갈 수 있습니다. 1도의 오차도 허용하지 않는 결벽에 가까운 통제가 에클립스의 기준입니다.
                </p>
              </div>
            </div>
            <div className="flex gap-6 items-start group">
              <div className="p-3 border border-black-pure/10 bg-black-pure/5 text-gold-accent group-hover:bg-gold-accent group-hover:text-white transition-all">
                <Users size={22} />
              </div>
              <div>
                <h4 className="text-[11px] font-sans tracking-[0.2em] text-black-pure uppercase font-bold mb-1">완벽한 대비의 조화</h4>
                <p className="text-[10px] text-black-pure/50 leading-relaxed font-sans uppercase tracking-widest">
                  막내 셰프들이 담당하는 섬세한 아뮤즈 부쉬와 주방의 긴장을 녹여버리는 백태웅의 포근한 수플레가 공존합니다.
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="relative bg-black-pure p-12 border border-black-pure/10 shadow-2xl"
        >
          <div className="absolute -top-4 -right-4 px-6 py-2 bg-gold-accent text-black-pure text-[9px] uppercase font-bold tracking-[0.4em] z-20">
            주방 조직도
          </div>
          
          <div className="space-y-6">
            <div className="pb-6 border-b border-white/10 flex items-center justify-between">
              <span className="text-[10px] tracking-[0.5em] text-gold-accent uppercase font-bold">직책 (Position)</span>
              <span className="text-[10px] tracking-[0.5em] text-gold-accent uppercase font-bold">성함 (Personnel)</span>
            </div>
            {staff.map((member, i) => (
              <div key={i} className="flex justify-between items-center group">
                <span className="text-[9px] font-sans tracking-[0.3em] text-white-pure/40 uppercase group-hover:text-gold-accent transition-colors">
                  {member.role}
                </span>
                <span className={`text-[11px] font-serif tracking-[0.1em] uppercase ${member.style}`}>
                  {member.name}
                </span>
              </div>
            ))}
          </div>

          <div className="mt-12 p-6 border border-white/5 bg-white/5">
            <p className="text-[9px] font-mono text-white-pure/30 uppercase tracking-[0.2em] leading-relaxed">
              * 모든 플레이트는 당신의 규율을 투영합니다. 실수는 곧 에클립스의 몰락입니다. 주방 내 정숙을 유지하십시오.
            </p>
          </div>
        </motion.div>
      </div>

      <div className="absolute left-6 top-0 h-full w-[1px] bg-black-pure/5" />
      <div className="absolute right-6 top-0 h-full w-[1px] bg-black-pure/5" />
    </section>
  );
}
