import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, Star, Utensils, Info, Calendar, MessageSquare } from "lucide-react";
import { Section } from "../types";

export function Navbar({ activeSection, onSectionChange }: { activeSection: Section, onSectionChange: (s: Section) => void }) {
  return (
    <header className="fixed top-0 w-full z-50 flex justify-between items-center px-6 md:px-12 py-6 md:py-8 border-b border-white/10 bg-gradient-to-b from-black-pure/90 to-transparent backdrop-blur-sm transition-all duration-700">
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="hidden lg:flex flex-col cursor-pointer"
        onClick={() => onSectionChange("home")}
      >
        <span className="text-[9px] tracking-[0.4em] uppercase opacity-40 font-sans mb-1">Fine Dining Experience</span>
        <span className="text-[11px] tracking-[0.2em] font-serif uppercase">Cheongdam, Seoul</span>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center cursor-pointer"
        onClick={() => onSectionChange("home")}
      >
        <h1 className="text-3xl md:text-4xl tracking-[0.4em] font-serif uppercase font-light ml-[0.4em] text-white-pure">Éclipse</h1>
        <div className="flex justify-center gap-1.5 mt-2">
          <span className="text-gold-accent text-[10px]">★</span>
          <span className="text-gold-accent text-[10px]">★</span>
          <span className="text-[9px] tracking-widest opacity-30 ml-1 uppercase font-sans">Michelin II Star</span>
        </div>
      </motion.div>

      <nav className="flex gap-4 md:gap-8 items-center">
        <div className="hidden md:flex gap-6 items-center">
          {[
            { id: "menu", label: "메뉴" },
            { id: "dining", label: "홀" },
            { id: "kitchen", label: "주방" },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id as Section)}
              className={`text-[10px] tracking-[0.3em] uppercase transition-all font-sans hover:text-gold-accent ${
                activeSection === item.id ? "text-gold-accent" : "text-white-pure/60"
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
        <button 
          onClick={() => onSectionChange("booking")}
          className="bg-gold-accent text-black-pure px-4 md:px-8 py-2 md:py-3 text-[10px] tracking-[0.3em] uppercase font-sans font-bold hover:bg-white-pure transition-colors"
        >
          예약하기
        </button>
      </nav>
    </header>
  );
}
