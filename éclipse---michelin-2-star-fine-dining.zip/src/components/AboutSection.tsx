import React from "react";
import { motion } from "motion/react";
import { MapPin, Clock, Phone, Mail } from "lucide-react";

export function AboutSection() {
  return (
    <section className="min-h-screen py-32 px-6 relative bg-black-pure flex items-center overflow-hidden">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-24 items-center relative z-10">
        <motion.div
           initial={{ opacity: 0, scale: 0.95 }}
           whileInView={{ opacity: 1, scale: 1 }}
           transition={{ duration: 1.2 }}
           className="relative aspect-[3/4] overflow-hidden border border-white/5"
        >
          <img 
            src="https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?auto=format&fit=crop&q=80" 
            alt="Éclipse Hall" 
            className="w-full h-full object-cover grayscale brightness-75 hover:grayscale-0 transition-all duration-1000"
            referrerPolicy="no-referrer"
          />
          <div className="absolute top-8 left-8 text-gold-accent font-sans text-[9px] tracking-[0.5em] uppercase font-bold">
            02 — ATMOSPHERIC CALM
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.2 }}
        >
          <span className="text-[10px] tracking-[0.4em] uppercase font-sans font-bold text-gold-accent mb-6 block underline decoration-gold-accent/30 underline-offset-8">THE DINING ROOM</span>
          <h2 className="text-5xl md:text-8xl font-serif mb-10 tracking-tighter leading-tight uppercase italic">
            조명 (The Light)
          </h2>
          
          <div className="space-y-10 text-white-pure/50 leading-relaxed tracking-widest text-sm md:text-base font-light font-sans uppercase">
            <p>
              홀 매니저 이해성의 완벽한 통제 아래 운영되는 에클립스의 다이닝 룸은 블랙과 골드만으로 구성된 침묵의 성소입니다. 
            </p>
            <p>
              무소음의 미학이 지배하는 이 공간에서, 당신은 오직 자신의 미각과 접시 위의 빛에만 집중하게 됩니다. 청담동의 중심에서 시간이 멈추는 극도의 평온을 경험하십시오.
            </p>
            <div className="pt-8 border-t border-white/10 flex flex-col gap-8">
              <div className="flex flex-col gap-4">
                <p className="text-[10px] tracking-[0.2em] text-white-pure/40 leading-relaxed">
                  에클립스는 미슐랭 2스타의 명예를 넘어, 3스타를 향한 끝없는 완벽을 추구합니다. 
                  우리의 공간은 모든 감각이 정지된 듯한 고요 속에서 오직 미식의 본질만을 탐구할 수 있도록 설계되었습니다.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="flex items-center gap-4 group">
                  <MapPin size={16} className="text-gold-accent" />
                  <div className="text-[10px] tracking-[0.3em] uppercase transition-colors group-hover:text-gold-accent">서울 강남구 청담동 3층 단독 건물</div>
                </div>
                <div className="flex items-center gap-4 group">
                  <Clock size={16} className="text-gold-accent" />
                  <div className="text-[10px] tracking-[0.3em] uppercase transition-colors group-hover:text-gold-accent">월-일 11:00-21:00 (브레이크 15:00)</div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      <div className="absolute right-12 bottom-12 text-[10px] tracking-widest uppercase writing-vertical font-sans opacity-20">
        Éclipse — Cheongdam Sanctuary
      </div>
    </section>
  );
}
