import React from "react";
import { motion } from "motion/react";
import { Star } from "lucide-react";

export function MenuSection() {
  const courses = [
    { 
      id: "01", 
      name: "L'ÉVEIL (각성)", 
      desc: "예술 작품처럼 피어나는 섬세한 아뮤즈 부쉬. 권시우 셰프와 막내(Ⓤ)의 지독한 결벽과 정교함으로 완성되는 서사의 시작입니다.", 
      label: "The Beginning" 
    },
    { 
      id: "02", 
      name: "LE COEUR (심장)", 
      desc: "참숯 훈연 한우 안심과 블랙 트러플 쥬(Jus). 루비처럼 붉은 단면을 위해 셰프 류진이 직접 온도를 통제하는 에클립스의 정수입니다.", 
      label: "The Signature" 
    },
    { 
      id: "03", 
      name: "LE REPOS (안식)", 
      desc: "바닐라 빈을 곁들인 수플레. Pâtissier 백태웅이 선사하는 환상적인 단맛이 주방의 날 선 긴장을 포근하게 녹여버립니다.", 
      label: "The Finale" 
    }
  ];

  return (
    <section className="min-h-screen py-32 px-6 bg-black-pure relative flex items-center overflow-hidden">
      <div className="absolute inset-0 geometric-pattern opacity-10 pointer-events-none" />

      <div className="max-w-5xl mx-auto w-full relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-end mb-24 border-b border-white/10 pb-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
          >
            <span className="text-[10px] tracking-[0.6em] uppercase font-sans font-bold text-gold-accent mb-4 block italic">완벽한 대비</span>
            <h2 className="text-6xl md:text-8xl font-serif tracking-tighter uppercase italic">L'ÉCLIPSE</h2>
          </motion.div>
          <div className="text-right">
            <p className="text-[10px] tracking-[0.4em] text-white-pure/40 font-sans uppercase mb-1">테이스팅 메뉴 (Dégustation)</p>
            <p className="text-[11px] tracking-[0.2em] text-gold-accent font-serif uppercase cursor-default">모던 프런치의 미학적 조화</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {courses.map((course, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.2 }}
              className="group relative pt-12 border-t border-white/5"
            >
              <div className="absolute top-4 left-0 text-[10px] font-mono text-gold-accent opacity-50 tracking-widest">
                {course.id}
              </div>
              <div className="mb-8">
                <h3 className="text-2xl font-serif tracking-tight text-white-pure group-hover:text-gold-accent transition-colors duration-500 mb-2 uppercase italic">
                  {course.name}
                </h3>
                <span className="text-[9px] tracking-[0.3em] text-white-pure/30 font-sans uppercase">{course.label}</span>
              </div>
              <p className="text-white-pure/60 text-xs leading-loose tracking-widest font-light uppercase">
                {course.desc}
              </p>
            </motion.div>
          ))}
        </div>

        <div className="mt-32 flex flex-col items-center">
          <div className="w-[1px] h-20 bg-gradient-to-b from-gold-accent to-transparent mb-8" />
          <p className="text-[10px] text-white-pure/20 tracking-[0.3em] uppercase max-w-sm text-center leading-relaxed font-sans">
            에클립스의 모든 접시는 확고한 의지의 표명입니다. 
            <br />우리는 집착을 요리합니다.
          </p>
        </div>
      </div>
    </section>
  );
}
