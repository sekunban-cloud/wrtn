export interface Message {
  role: "user" | "model";
  parts: { text: string }[];
}

export interface Character {
  name: string;
  role: string;
  description: string;
  systemInstruction: string;
}

export type Section = "home" | "menu" | "dining" | "kitchen" | "booking";
