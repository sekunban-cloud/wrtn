import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { AboutSection } from "./components/AboutSection";
import { MenuSection } from "./components/MenuSection";
import { KitchenSection } from "./components/KitchenSection";
import { Section } from "./types";

export default function App() {
  const [activeSection, setActiveSection] = useState<Section>("home");
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowContent(true), 500);
    return () => clearTimeout(timer);
  }, []);

  const handleSectionChange = (section: Section) => {
    setActiveSection(section);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="bg-black-pure text-white-pure font-sans min-h-screen relative overflow-x-hidden">
      {/* Geometric Decorative Motif */}
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] md:w-[500px] h-[300px] md:h-[500px] border border-white/5 rounded-full flex items-center justify-center pointer-events-none z-0">
        <div className="w-[280px] md:w-[460px] h-[280px] md:h-[460px] border border-gold-accent/10 rounded-full flex items-center justify-center">
          <div className="w-[1px] h-full bg-gradient-to-b from-transparent via-gold-accent/20 to-transparent"></div>
        </div>
      </div>

      <AnimatePresence>
        {showContent && (
          <>
            <Navbar activeSection={activeSection} onSectionChange={handleSectionChange} />
            
            <main className="relative z-10">
              {activeSection === "home" && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 1 }}
                >
                  <Hero onExplore={() => setActiveSection("kitchen")} />
                  <AboutSection />
                </motion.div>
              )}

              {activeSection === "menu" && (
                <motion.div
                  key="menu"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.02 }}
                  transition={{ duration: 0.8 }}
                >
                  <MenuSection />
                </motion.div>
              )}

              {activeSection === "dining" && (
                <motion.div
                  key="dining"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.8 }}
                >
                  <AboutSection />
                </motion.div>
              )}

              {activeSection === "kitchen" && (
                <motion.div
                  key="kitchen"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.8 }}
                >
                  <KitchenSection />
                </motion.div>
              )}

              {activeSection === "booking" && (
                <motion.div
                  key="booking"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="min-h-screen flex items-center justify-center pt-24"
                >
                  <div className="text-center px-6">
                    <span className="text-[10px] tracking-[0.4em] uppercase font-sans font-bold text-gold-accent mb-4 block">RESERVATION</span>
                    <h2 className="text-5xl md:text-7xl font-serif mb-8 tracking-tighter uppercase italic">예약 안내</h2>
                    <p className="text-white-pure/40 text-[11px] tracking-[0.3em] uppercase mb-12">매주 수요일 휴무 | 다음 시즌 예약은 매월 1일 오픈</p>
                    <div className="max-w-md mx-auto p-12 border border-white/10 bg-white/5 backdrop-blur-md mb-12">
                      <p className="text-[10px] tracking-[0.2em] font-mono leading-loose text-white-pure/40 uppercase">
                        2026년 6월 예약이 모두 마감되었습니다.
                        <br /><br />
                        취소석 발생 시 대기 신청 순서대로 안내드립니다.
                      </p>
                    </div>
                    <button className="px-12 py-5 bg-gold-accent text-black-pure text-[10px] tracking-[0.4em] uppercase font-bold hover:bg-white-pure transition-all">
                      대기 명단 등록
                    </button>
                  </div>
                </motion.div>
              )}
            </main>

            <footer className="relative z-20 py-16 px-6 md:px-12 border-t border-white/10 bg-gradient-to-t from-black-pure to-transparent">
              <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-end gap-12">
                <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-4">
                    <span className="text-[9px] tracking-widest opacity-40 uppercase font-sans">Owner</span>
                    <span className="text-[11px] tracking-[0.3em] font-serif uppercase">최세환 (Choi Se-Hwan)</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-[9px] tracking-widest opacity-40 uppercase font-sans">Executive</span>
                    <span className="text-[11px] tracking-[0.3em] font-serif uppercase">류진 (Jin Ryu)</span>
                  </div>
                  <div className="mt-8 flex gap-8 text-[9px] text-white-pure/20 tracking-[0.2em] uppercase font-sans">
                    <a href="#" className="hover:text-gold-accent transition-colors">개인정보처리방침</a>
                    <a href="#" className="hover:text-gold-accent transition-colors">이용약관</a>
                    <a href="#" className="hover:text-gold-accent transition-colors">프레스</a>
                  </div>
                </div>

                <div className="text-right flex flex-col gap-2">
                  <div className="text-[9px] tracking-[0.3em] uppercase opacity-40 mb-2 font-sans">영업 시간</div>
                  <div className="text-[11px] tracking-[0.2em] font-serif uppercase">월 - 일 (수요일 휴무)</div>
                  <div className="text-[11px] tracking-[0.2em] font-serif uppercase">11:00 — 21:00 / 브레이크 타임 15:00 — 17:00</div>
                  <div className="mt-6 text-[10px] text-gold-accent tracking-[0.3em] uppercase font-bold">© 2026 ÉCLIPSE</div>
                </div>
              </div>
            </footer>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
